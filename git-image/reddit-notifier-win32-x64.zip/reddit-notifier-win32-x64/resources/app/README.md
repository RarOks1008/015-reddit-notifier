# 015-reddit-notifier
App for getting notified when a new post is posted on a subreddit made in Electron and AngularJS

## TODO

- ubaci instalaciju za app preko nekog build-a

- sredi readme i ubaci slike kako izgleda otprilike app na github